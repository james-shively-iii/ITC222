--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6
-- Dumped by pg_dump version 10.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.personaddress DROP CONSTRAINT personaddress_personkey_fkey;
ALTER TABLE ONLY public.logintable DROP CONSTRAINT logintable_personkey_fkey1;
ALTER TABLE ONLY public.logintable DROP CONSTRAINT logintable_personkey_fkey;
ALTER TABLE ONLY public.loginhistory DROP CONSTRAINT loginhistory_loginkey_fkey;
ALTER TABLE ONLY public.grantstatus DROP CONSTRAINT grantstatus_statuskey_fkey;
ALTER TABLE ONLY public.grantstatus DROP CONSTRAINT grantstatus_grantapplicationkey_fkey;
ALTER TABLE ONLY public.grantreview DROP CONSTRAINT grantreview_grantapplicationkey_fkey;
ALTER TABLE ONLY public.grantreview DROP CONSTRAINT grantreview_employeekey_fkey;
ALTER TABLE ONLY public.grantapplication DROP CONSTRAINT grantapplication_personkey_fkey;
ALTER TABLE ONLY public.grantapplication DROP CONSTRAINT grantapplication_granttypekey_fkey;
ALTER TABLE ONLY public.employeeposition DROP CONSTRAINT employeeposition_positionkey_fkey;
ALTER TABLE ONLY public.employeeposition DROP CONSTRAINT employeeposition_employeekey_fkey;
ALTER TABLE ONLY public.employee DROP CONSTRAINT employee_personkey_fkey;
ALTER TABLE ONLY public.donation DROP CONSTRAINT donation_personkey_fkey;
DROP INDEX public.idx_lastname;
ALTER TABLE ONLY public.status DROP CONSTRAINT status_pkey;
ALTER TABLE ONLY public.personaddress DROP CONSTRAINT personaddress_pkey;
ALTER TABLE ONLY public.person DROP CONSTRAINT person_pkey;
ALTER TABLE ONLY public.person DROP CONSTRAINT person_personemail_key;
ALTER TABLE ONLY public.logintable DROP CONSTRAINT logintable_pkey;
ALTER TABLE ONLY public.loginhistory DROP CONSTRAINT loginhistory_pkey;
ALTER TABLE ONLY public.jobposition DROP CONSTRAINT jobposition_pkey;
ALTER TABLE ONLY public.granttype DROP CONSTRAINT granttype_pkey;
ALTER TABLE ONLY public.grantstatus DROP CONSTRAINT grantstatus_pkey;
ALTER TABLE ONLY public.grantreview DROP CONSTRAINT grantreview_pkey;
ALTER TABLE ONLY public.grantapplication DROP CONSTRAINT grantapplication_pkey;
ALTER TABLE ONLY public.employeeposition DROP CONSTRAINT employeeposition_pkey;
ALTER TABLE ONLY public.employee DROP CONSTRAINT employee_pkey;
ALTER TABLE ONLY public.donation DROP CONSTRAINT donation_pkey;
ALTER TABLE ONLY public.businessrule DROP CONSTRAINT businessrule_pkey;
ALTER TABLE public.status ALTER COLUMN statuskey DROP DEFAULT;
ALTER TABLE public.personaddress ALTER COLUMN personaddresskey DROP DEFAULT;
ALTER TABLE public.person ALTER COLUMN personkey DROP DEFAULT;
ALTER TABLE public.logintable ALTER COLUMN loginkey DROP DEFAULT;
ALTER TABLE public.loginhistory ALTER COLUMN loginhistorykey DROP DEFAULT;
ALTER TABLE public.jobposition ALTER COLUMN positionkey DROP DEFAULT;
ALTER TABLE public.granttype ALTER COLUMN granttypekey DROP DEFAULT;
ALTER TABLE public.grantstatus ALTER COLUMN grantstatuskey DROP DEFAULT;
ALTER TABLE public.grantreview ALTER COLUMN grantreviewkey DROP DEFAULT;
ALTER TABLE public.grantapplication ALTER COLUMN grantapplicationkey DROP DEFAULT;
ALTER TABLE public.employeeposition ALTER COLUMN employeepositionkey DROP DEFAULT;
ALTER TABLE public.employee ALTER COLUMN employeekey DROP DEFAULT;
ALTER TABLE public.donation ALTER COLUMN donationkey DROP DEFAULT;
ALTER TABLE public.businessrule ALTER COLUMN businessrulekey DROP DEFAULT;
DROP SEQUENCE public.status_statuskey_seq;
DROP TABLE public.status;
DROP SEQUENCE public.pk_seq;
DROP SEQUENCE public.personaddress_personaddresskey_seq;
DROP SEQUENCE public.person_personkey_seq;
DROP VIEW public.people;
DROP VIEW public.numberserved;
DROP SEQUENCE public.logintable_loginkey_seq;
DROP TABLE public.logintable;
DROP SEQUENCE public.loginhistory_loginhistorykey_seq;
DROP TABLE public.loginhistory;
DROP SEQUENCE public.jobposition_positionkey_seq;
DROP SEQUENCE public.granttype_granttypekey_seq;
DROP SEQUENCE public.grantstatus_grantstatuskey_seq;
DROP TABLE public.grantstatus;
DROP SEQUENCE public.grantreview_grantreviewkey_seq;
DROP TABLE public.grantreview;
DROP SEQUENCE public.grantapplication_grantapplicationkey_seq;
DROP SEQUENCE public.employeeposition_employeepositionkey_seq;
DROP SEQUENCE public.employee_employeekey_seq;
DROP SEQUENCE public.donation_donationkey_seq;
DROP SEQUENCE public.businessrule_businessrulekey_seq;
DROP TABLE public.businessrule;
DROP VIEW employeeschema.seattleaddresses;
DROP TABLE public.personaddress;
DROP MATERIALIZED VIEW employeeschema.grantreview;
DROP TABLE public.granttype;
DROP TABLE public.grantapplication;
DROP VIEW employeeschema.employeeview;
DROP TABLE public.jobposition;
DROP TABLE public.employeeposition;
DROP TABLE public.employee;
DROP VIEW employeeschema.emailview;
DROP MATERIALIZED VIEW donorschema.topdonors;
DROP TABLE public.person;
DROP TABLE public.donation;
DROP FUNCTION public.validatelogin(username character varying, pass character varying);
DROP FUNCTION public.makeusername(firstname text, lastname text);
DROP FUNCTION public.editperson(pkey integer, firstname text, lastname text, email text, phone text, apartment text, street text, city text, state character, zipcode character);
DROP FUNCTION public.cube(num integer);
DROP FUNCTION public.createpassword(pass character varying);
DROP FUNCTION public.addperson(firstname text, lastname text, email text, phone text, apartment text, street text, city text, state character, zipcode character, passwd character varying);
DROP FUNCTION employeeschema.donationpercentages(amount numeric, percentage numeric);
DROP FUNCTION donorschema.getdonations(donorkey integer);
DROP EXTENSION "uuid-ossp";
DROP EXTENSION pgcrypto;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
DROP SCHEMA employeeschema;
DROP SCHEMA donorschema;
DROP SCHEMA clientschema;
--
-- Name: clientschema; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA clientschema;


ALTER SCHEMA clientschema OWNER TO postgres;

--
-- Name: donorschema; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA donorschema;


ALTER SCHEMA donorschema OWNER TO postgres;

--
-- Name: employeeschema; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA employeeschema;


ALTER SCHEMA employeeschema OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: getdonations(integer); Type: FUNCTION; Schema: donorschema; Owner: postgres
--

CREATE FUNCTION donorschema.getdonations(donorkey integer) RETURNS TABLE("Date" timestamp without time zone, "Amount" numeric, "Validation" uuid)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
SELECT donationdate, donationamount, donationvalidation
FROM donation
WHERE personkey=donorkey;
END;
$$;


ALTER FUNCTION donorschema.getdonations(donorkey integer) OWNER TO postgres;

--
-- Name: donationpercentages(numeric, numeric); Type: FUNCTION; Schema: employeeschema; Owner: postgres
--

CREATE FUNCTION employeeschema.donationpercentages(amount numeric, percentage numeric) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
BEGIN
IF percentage > 1
THEN
	RETURN amount * percentage / 100;
ELSE
	RETURN amount * percentage;
END IF;
END;
$$;


ALTER FUNCTION employeeschema.donationpercentages(amount numeric, percentage numeric) OWNER TO postgres;

--
-- Name: addperson(text, text, text, text, text, text, text, character, character, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.addperson(firstname text, lastname text, email text, phone text, apartment text, street text, city text, state character, zipcode character, passwd character varying) RETURNS void
    LANGUAGE sql
    AS $$
INSERT INTO person(
	personfirstname, personlastname, personemail, personprimaryphone,
	persondateadded)
VALUES(firstname, lastname, email, phone, current_timestamp);
INSERT INTO personaddress(
	personkey, personaddressapt, personaddressstreet,
	personaddresscity, personaddressstate,
	personaddresszipcode
)
VALUES(CURRVAL('person_personkey_seq'), apartment, street, city, "state", zipcode);
INSERT INTO logintable(personkey, personusername, personpassword)
VALUES(CURRVAL('person_personkey_seq'), makeusername(firstname, lastname), createpassword(passwd));
$$;


ALTER FUNCTION public.addperson(firstname text, lastname text, email text, phone text, apartment text, street text, city text, state character, zipcode character, passwd character varying) OWNER TO postgres;

--
-- Name: createpassword(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.createpassword(pass character varying) RETURNS text
    LANGUAGE sql
    AS $$Select crypt(pass, gen_salt('bf', 8))$$;


ALTER FUNCTION public.createpassword(pass character varying) OWNER TO postgres;

--
-- Name: cube(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cube(num integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN num * num * num;
END;
$$;


ALTER FUNCTION public.cube(num integer) OWNER TO postgres;

--
-- Name: editperson(integer, text, text, text, text, text, text, text, character, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.editperson(pkey integer, firstname text, lastname text, email text, phone text, apartment text, street text, city text, state character, zipcode character) RETURNS void
    LANGUAGE sql
    AS $$
UPDATE person
SET personfirstname=firstname,
personlastname=lastname,
personemail=email,
personprimaryphone=phone
WHERE personkey=pkey;
UPDATE personaddress
SET personaddressapt=apartment,
personaddressstreet="state",
personaddresszipcode=zipcode
WHERE personkey=pkey;
$$;


ALTER FUNCTION public.editperson(pkey integer, firstname text, lastname text, email text, phone text, apartment text, street text, city text, state character, zipcode character) OWNER TO postgres;

--
-- Name: makeusername(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.makeusername(firstname text, lastname text) RETURNS text
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN LOWER(SUBSTRING(firstname, 1,1) || lastname);
END;
$$;


ALTER FUNCTION public.makeusername(firstname text, lastname text) OWNER TO postgres;

--
-- Name: validatelogin(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.validatelogin(username character varying, pass character varying) RETURNS integer
    LANGUAGE sql
    AS $$
Select LoginKey from LoginTable where PersonUserName =username
and PersonPassword=crypt(pass,PersonPassword)
$$;


ALTER FUNCTION public.validatelogin(username character varying, pass character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: donation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.donation (
    donationkey integer NOT NULL,
    personkey integer,
    donationamount numeric NOT NULL,
    donationdate timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    donationvalidation uuid DEFAULT public.uuid_generate_v4()
);


ALTER TABLE public.donation OWNER TO postgres;

--
-- Name: person; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.person (
    personkey integer NOT NULL,
    personlastname character varying(255) NOT NULL,
    personfirstname character varying(255),
    personemail character varying(255) NOT NULL,
    personprimaryphone character(13),
    persondateadded date NOT NULL
);


ALTER TABLE public.person OWNER TO postgres;

--
-- Name: topdonors; Type: MATERIALIZED VIEW; Schema: donorschema; Owner: postgres
--

CREATE MATERIALIZED VIEW donorschema.topdonors AS
 SELECT person.personlastname AS lastname,
    person.personfirstname AS firstname,
    donation.donationdate,
    donation.donationamount AS amount
   FROM (public.person
     JOIN public.donation ON ((person.personkey = donation.personkey)))
  ORDER BY donation.donationamount DESC
 LIMIT 10
  WITH NO DATA;


ALTER TABLE donorschema.topdonors OWNER TO postgres;

--
-- Name: emailview; Type: VIEW; Schema: employeeschema; Owner: postgres
--

CREATE VIEW employeeschema.emailview AS
 SELECT person.personlastname,
    person.personfirstname,
    person.personemail
   FROM public.person
  WITH CASCADED CHECK OPTION;


ALTER TABLE employeeschema.emailview OWNER TO postgres;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    employeekey integer NOT NULL,
    personkey integer
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: employeeposition; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employeeposition (
    employeepositionkey integer NOT NULL,
    employeekey integer,
    positionkey integer,
    employeepositionstartdate date
);


ALTER TABLE public.employeeposition OWNER TO postgres;

--
-- Name: jobposition; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jobposition (
    positionkey integer NOT NULL,
    positionname character varying(255),
    positiondescript character varying(255)
);


ALTER TABLE public.jobposition OWNER TO postgres;

--
-- Name: employeeview; Type: VIEW; Schema: employeeschema; Owner: postgres
--

CREATE VIEW employeeschema.employeeview AS
 SELECT p.personfirstname AS firstname,
    p.personlastname AS lastname,
    p.personemail AS email,
    jp.positionname AS "position",
    ep.employeepositionstartdate AS startdate
   FROM (((public.person p
     JOIN public.employee e ON ((p.personkey = e.personkey)))
     JOIN public.employeeposition ep ON ((e.employeekey = ep.employeekey)))
     JOIN public.jobposition jp ON ((jp.positionkey = ep.positionkey)));


ALTER TABLE employeeschema.employeeview OWNER TO postgres;

--
-- Name: grantapplication; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grantapplication (
    grantapplicationkey integer NOT NULL,
    grantapplicationdate timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    personkey integer,
    granttypekey integer,
    grantapplicationamount numeric NOT NULL,
    grantapplicationexplain text NOT NULL,
    grantapplicationconfirm uuid DEFAULT public.uuid_generate_v4()
);


ALTER TABLE public.grantapplication OWNER TO postgres;

--
-- Name: granttype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.granttype (
    granttypekey integer NOT NULL,
    granttypename character varying(255),
    granttypeonetimemax numeric NOT NULL,
    granttypelifetimemax numeric NOT NULL
);


ALTER TABLE public.granttype OWNER TO postgres;

--
-- Name: grantreview; Type: MATERIALIZED VIEW; Schema: employeeschema; Owner: postgres
--

CREATE MATERIALIZED VIEW employeeschema.grantreview AS
 SELECT grantapplication.grantapplicationkey AS "Key",
    grantapplication.grantapplicationdate AS "Date",
    granttype.granttypename AS "Grant Name",
    person.personlastname AS "Last Name",
    grantapplication.grantapplicationamount AS "Amount of Grant"
   FROM ((public.person
     JOIN public.grantapplication USING (personkey))
     JOIN public.granttype USING (granttypekey))
  WITH NO DATA;


ALTER TABLE employeeschema.grantreview OWNER TO postgres;

--
-- Name: personaddress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personaddress (
    personaddresskey integer NOT NULL,
    personkey integer,
    personaddressstreet character varying(255) NOT NULL,
    personaddresscity character varying(255) DEFAULT 'Seattle'::character varying,
    personaddressstate character(2) DEFAULT 'WA'::bpchar,
    personaddresszipcode character(11) NOT NULL,
    personaddressapt character varying(255)
);


ALTER TABLE public.personaddress OWNER TO postgres;

--
-- Name: seattleaddresses; Type: VIEW; Schema: employeeschema; Owner: postgres
--

CREATE VIEW employeeschema.seattleaddresses AS
 SELECT personaddress.personkey,
    personaddress.personaddressapt AS apartment,
    personaddress.personaddressstreet AS street,
    personaddress.personaddresscity AS city,
    personaddress.personaddressstate AS state,
    personaddress.personaddresszipcode AS postalcode
   FROM public.personaddress
  WHERE ((personaddress.personaddresscity)::text = 'Seattle'::text)
  WITH CASCADED CHECK OPTION;


ALTER TABLE employeeschema.seattleaddresses OWNER TO postgres;

--
-- Name: businessrule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.businessrule (
    businessrulekey integer NOT NULL,
    businessruletext text NOT NULL
);


ALTER TABLE public.businessrule OWNER TO postgres;

--
-- Name: businessrule_businessrulekey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.businessrule_businessrulekey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.businessrule_businessrulekey_seq OWNER TO postgres;

--
-- Name: businessrule_businessrulekey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.businessrule_businessrulekey_seq OWNED BY public.businessrule.businessrulekey;


--
-- Name: donation_donationkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.donation_donationkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.donation_donationkey_seq OWNER TO postgres;

--
-- Name: donation_donationkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.donation_donationkey_seq OWNED BY public.donation.donationkey;


--
-- Name: employee_employeekey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_employeekey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_employeekey_seq OWNER TO postgres;

--
-- Name: employee_employeekey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_employeekey_seq OWNED BY public.employee.employeekey;


--
-- Name: employeeposition_employeepositionkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employeeposition_employeepositionkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employeeposition_employeepositionkey_seq OWNER TO postgres;

--
-- Name: employeeposition_employeepositionkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employeeposition_employeepositionkey_seq OWNED BY public.employeeposition.employeepositionkey;


--
-- Name: grantapplication_grantapplicationkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grantapplication_grantapplicationkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grantapplication_grantapplicationkey_seq OWNER TO postgres;

--
-- Name: grantapplication_grantapplicationkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grantapplication_grantapplicationkey_seq OWNED BY public.grantapplication.grantapplicationkey;


--
-- Name: grantreview; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grantreview (
    grantreviewkey integer NOT NULL,
    grantapplicationkey integer,
    employeekey integer,
    grantreviewdate timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    grantreviewcomment text
);


ALTER TABLE public.grantreview OWNER TO postgres;

--
-- Name: grantreview_grantreviewkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grantreview_grantreviewkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grantreview_grantreviewkey_seq OWNER TO postgres;

--
-- Name: grantreview_grantreviewkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grantreview_grantreviewkey_seq OWNED BY public.grantreview.grantreviewkey;


--
-- Name: grantstatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grantstatus (
    grantstatuskey integer NOT NULL,
    grantapplicationkey integer,
    statuskey integer DEFAULT 1,
    grantstatusfinalallocation numeric
);


ALTER TABLE public.grantstatus OWNER TO postgres;

--
-- Name: grantstatus_grantstatuskey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grantstatus_grantstatuskey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grantstatus_grantstatuskey_seq OWNER TO postgres;

--
-- Name: grantstatus_grantstatuskey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grantstatus_grantstatuskey_seq OWNED BY public.grantstatus.grantstatuskey;


--
-- Name: granttype_granttypekey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.granttype_granttypekey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.granttype_granttypekey_seq OWNER TO postgres;

--
-- Name: granttype_granttypekey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.granttype_granttypekey_seq OWNED BY public.granttype.granttypekey;


--
-- Name: jobposition_positionkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.jobposition_positionkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobposition_positionkey_seq OWNER TO postgres;

--
-- Name: jobposition_positionkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.jobposition_positionkey_seq OWNED BY public.jobposition.positionkey;


--
-- Name: loginhistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loginhistory (
    loginhistorykey integer NOT NULL,
    loginkey integer,
    logintimestamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.loginhistory OWNER TO postgres;

--
-- Name: loginhistory_loginhistorykey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.loginhistory_loginhistorykey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.loginhistory_loginhistorykey_seq OWNER TO postgres;

--
-- Name: loginhistory_loginhistorykey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.loginhistory_loginhistorykey_seq OWNED BY public.loginhistory.loginhistorykey;


--
-- Name: logintable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logintable (
    loginkey integer NOT NULL,
    personkey integer,
    personusername character varying(50) NOT NULL,
    personpassword text NOT NULL
);


ALTER TABLE public.logintable OWNER TO postgres;

--
-- Name: logintable_loginkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.logintable_loginkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logintable_loginkey_seq OWNER TO postgres;

--
-- Name: logintable_loginkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.logintable_loginkey_seq OWNED BY public.logintable.loginkey;


--
-- Name: numberserved; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.numberserved AS
 SELECT date_part('year'::text, grantapplication.grantapplicationdate) AS "Year",
    count(grantapplication.grantapplicationkey) AS "Number",
    sum(grantapplication.grantapplicationamount) AS "Total"
   FROM public.grantapplication
  GROUP BY (date_part('year'::text, grantapplication.grantapplicationdate))
  ORDER BY (date_part('year'::text, grantapplication.grantapplicationdate));


ALTER TABLE public.numberserved OWNER TO postgres;

--
-- Name: people; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.people AS
 SELECT person.personkey AS "ID",
    person.personfirstname AS "FirstName",
    person.personlastname AS "LastName",
    person.personemail AS "Email",
    person.personprimaryphone AS "Phone",
    person.persondateadded AS "DateAdded"
   FROM public.person
  ORDER BY person.persondateadded;


ALTER TABLE public.people OWNER TO postgres;

--
-- Name: person_personkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.person_personkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.person_personkey_seq OWNER TO postgres;

--
-- Name: person_personkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.person_personkey_seq OWNED BY public.person.personkey;


--
-- Name: personaddress_personaddresskey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personaddress_personaddresskey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personaddress_personaddresskey_seq OWNER TO postgres;

--
-- Name: personaddress_personaddresskey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personaddress_personaddresskey_seq OWNED BY public.personaddress.personaddresskey;


--
-- Name: pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pk_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pk_seq OWNER TO postgres;

--
-- Name: status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status (
    statuskey integer NOT NULL,
    statusname character varying(255) NOT NULL
);


ALTER TABLE public.status OWNER TO postgres;

--
-- Name: status_statuskey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.status_statuskey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_statuskey_seq OWNER TO postgres;

--
-- Name: status_statuskey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.status_statuskey_seq OWNED BY public.status.statuskey;


--
-- Name: businessrule businessrulekey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.businessrule ALTER COLUMN businessrulekey SET DEFAULT nextval('public.businessrule_businessrulekey_seq'::regclass);


--
-- Name: donation donationkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.donation ALTER COLUMN donationkey SET DEFAULT nextval('public.donation_donationkey_seq'::regclass);


--
-- Name: employee employeekey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee ALTER COLUMN employeekey SET DEFAULT nextval('public.employee_employeekey_seq'::regclass);


--
-- Name: employeeposition employeepositionkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employeeposition ALTER COLUMN employeepositionkey SET DEFAULT nextval('public.employeeposition_employeepositionkey_seq'::regclass);


--
-- Name: grantapplication grantapplicationkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grantapplication ALTER COLUMN grantapplicationkey SET DEFAULT nextval('public.grantapplication_grantapplicationkey_seq'::regclass);


--
-- Name: grantreview grantreviewkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grantreview ALTER COLUMN grantreviewkey SET DEFAULT nextval('public.grantreview_grantreviewkey_seq'::regclass);


--
-- Name: grantstatus grantstatuskey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grantstatus ALTER COLUMN grantstatuskey SET DEFAULT nextval('public.grantstatus_grantstatuskey_seq'::regclass);


--
-- Name: granttype granttypekey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.granttype ALTER COLUMN granttypekey SET DEFAULT nextval('public.granttype_granttypekey_seq'::regclass);


--
-- Name: jobposition positionkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobposition ALTER COLUMN positionkey SET DEFAULT nextval('public.jobposition_positionkey_seq'::regclass);


--
-- Name: loginhistory loginhistorykey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loginhistory ALTER COLUMN loginhistorykey SET DEFAULT nextval('public.loginhistory_loginhistorykey_seq'::regclass);


--
-- Name: logintable loginkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logintable ALTER COLUMN loginkey SET DEFAULT nextval('public.logintable_loginkey_seq'::regclass);


--
-- Name: person personkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person ALTER COLUMN personkey SET DEFAULT nextval('public.person_personkey_seq'::regclass);


--
-- Name: personaddress personaddresskey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personaddress ALTER COLUMN personaddresskey SET DEFAULT nextval('public.personaddress_personaddresskey_seq'::regclass);


--
-- Name: status statuskey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status ALTER COLUMN statuskey SET DEFAULT nextval('public.status_statuskey_seq'::regclass);


--
-- Data for Name: businessrule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.businessrule (businessrulekey, businessruletext) FROM stdin;
\.
COPY public.businessrule (businessrulekey, businessruletext) FROM '$$PATH$$/3045.dat';

--
-- Data for Name: donation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.donation (donationkey, personkey, donationamount, donationdate, donationvalidation) FROM stdin;
\.
COPY public.donation (donationkey, personkey, donationamount, donationdate, donationvalidation) FROM '$$PATH$$/3047.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (employeekey, personkey) FROM stdin;
\.
COPY public.employee (employeekey, personkey) FROM '$$PATH$$/3049.dat';

--
-- Data for Name: employeeposition; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employeeposition (employeepositionkey, employeekey, positionkey, employeepositionstartdate) FROM stdin;
\.
COPY public.employeeposition (employeepositionkey, employeekey, positionkey, employeepositionstartdate) FROM '$$PATH$$/3051.dat';

--
-- Data for Name: grantapplication; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grantapplication (grantapplicationkey, grantapplicationdate, personkey, granttypekey, grantapplicationamount, grantapplicationexplain, grantapplicationconfirm) FROM stdin;
\.
COPY public.grantapplication (grantapplicationkey, grantapplicationdate, personkey, granttypekey, grantapplicationamount, grantapplicationexplain, grantapplicationconfirm) FROM '$$PATH$$/3053.dat';

--
-- Data for Name: grantreview; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grantreview (grantreviewkey, grantapplicationkey, employeekey, grantreviewdate, grantreviewcomment) FROM stdin;
\.
COPY public.grantreview (grantreviewkey, grantapplicationkey, employeekey, grantreviewdate, grantreviewcomment) FROM '$$PATH$$/3055.dat';

--
-- Data for Name: grantstatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grantstatus (grantstatuskey, grantapplicationkey, statuskey, grantstatusfinalallocation) FROM stdin;
\.
COPY public.grantstatus (grantstatuskey, grantapplicationkey, statuskey, grantstatusfinalallocation) FROM '$$PATH$$/3057.dat';

--
-- Data for Name: granttype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.granttype (granttypekey, granttypename, granttypeonetimemax, granttypelifetimemax) FROM stdin;
\.
COPY public.granttype (granttypekey, granttypename, granttypeonetimemax, granttypelifetimemax) FROM '$$PATH$$/3059.dat';

--
-- Data for Name: jobposition; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jobposition (positionkey, positionname, positiondescript) FROM stdin;
\.
COPY public.jobposition (positionkey, positionname, positiondescript) FROM '$$PATH$$/3061.dat';

--
-- Data for Name: loginhistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loginhistory (loginhistorykey, loginkey, logintimestamp) FROM stdin;
\.
COPY public.loginhistory (loginhistorykey, loginkey, logintimestamp) FROM '$$PATH$$/3063.dat';

--
-- Data for Name: logintable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logintable (loginkey, personkey, personusername, personpassword) FROM stdin;
\.
COPY public.logintable (loginkey, personkey, personusername, personpassword) FROM '$$PATH$$/3065.dat';

--
-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.person (personkey, personlastname, personfirstname, personemail, personprimaryphone, persondateadded) FROM stdin;
\.
COPY public.person (personkey, personlastname, personfirstname, personemail, personprimaryphone, persondateadded) FROM '$$PATH$$/3067.dat';

--
-- Data for Name: personaddress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personaddress (personaddresskey, personkey, personaddressstreet, personaddresscity, personaddressstate, personaddresszipcode, personaddressapt) FROM stdin;
\.
COPY public.personaddress (personaddresskey, personkey, personaddressstreet, personaddresscity, personaddressstate, personaddresszipcode, personaddressapt) FROM '$$PATH$$/3069.dat';

--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status (statuskey, statusname) FROM stdin;
\.
COPY public.status (statuskey, statusname) FROM '$$PATH$$/3071.dat';

--
-- Name: businessrule_businessrulekey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.businessrule_businessrulekey_seq', 1, false);


--
-- Name: donation_donationkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.donation_donationkey_seq', 68, true);


--
-- Name: employee_employeekey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_employeekey_seq', 7, true);


--
-- Name: employeeposition_employeepositionkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employeeposition_employeepositionkey_seq', 17, true);


--
-- Name: grantapplication_grantapplicationkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grantapplication_grantapplicationkey_seq', 55, true);


--
-- Name: grantreview_grantreviewkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grantreview_grantreviewkey_seq', 67, true);


--
-- Name: grantstatus_grantstatuskey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grantstatus_grantstatuskey_seq', 54, true);


--
-- Name: granttype_granttypekey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.granttype_granttypekey_seq', 9, true);


--
-- Name: jobposition_positionkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.jobposition_positionkey_seq', 17, true);


--
-- Name: loginhistory_loginhistorykey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.loginhistory_loginhistorykey_seq', 1, true);


--
-- Name: logintable_loginkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.logintable_loginkey_seq', 135, true);


--
-- Name: person_personkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.person_personkey_seq', 136, true);


--
-- Name: personaddress_personaddresskey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personaddress_personaddresskey_seq', 205, true);


--
-- Name: pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pk_seq', 1, false);


--
-- Name: status_statuskey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.status_statuskey_seq', 4, true);


--
-- Name: businessrule businessrule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.businessrule
    ADD CONSTRAINT businessrule_pkey PRIMARY KEY (businessrulekey);


--
-- Name: donation donation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.donation
    ADD CONSTRAINT donation_pkey PRIMARY KEY (donationkey);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (employeekey);


--
-- Name: employeeposition employeeposition_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employeeposition
    ADD CONSTRAINT employeeposition_pkey PRIMARY KEY (employeepositionkey);


--
-- Name: grantapplication grantapplication_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grantapplication
    ADD CONSTRAINT grantapplication_pkey PRIMARY KEY (grantapplicationkey);


--
-- Name: grantreview grantreview_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grantreview
    ADD CONSTRAINT grantreview_pkey PRIMARY KEY (grantreviewkey);


--
-- Name: grantstatus grantstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grantstatus
    ADD CONSTRAINT grantstatus_pkey PRIMARY KEY (grantstatuskey);


--
-- Name: granttype granttype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.granttype
    ADD CONSTRAINT granttype_pkey PRIMARY KEY (granttypekey);


--
-- Name: jobposition jobposition_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobposition
    ADD CONSTRAINT jobposition_pkey PRIMARY KEY (positionkey);


--
-- Name: loginhistory loginhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loginhistory
    ADD CONSTRAINT loginhistory_pkey PRIMARY KEY (loginhistorykey);


--
-- Name: logintable logintable_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logintable
    ADD CONSTRAINT logintable_pkey PRIMARY KEY (loginkey);


--
-- Name: person person_personemail_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_personemail_key UNIQUE (personemail);


--
-- Name: person person_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_pkey PRIMARY KEY (personkey);


--
-- Name: personaddress personaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personaddress
    ADD CONSTRAINT personaddress_pkey PRIMARY KEY (personaddresskey);


--
-- Name: status status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_pkey PRIMARY KEY (statuskey);


--
-- Name: idx_lastname; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lastname ON public.person USING btree (personlastname);


--
-- Name: donation donation_personkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.donation
    ADD CONSTRAINT donation_personkey_fkey FOREIGN KEY (personkey) REFERENCES public.person(personkey);


--
-- Name: employee employee_personkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_personkey_fkey FOREIGN KEY (personkey) REFERENCES public.person(personkey);


--
-- Name: employeeposition employeeposition_employeekey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employeeposition
    ADD CONSTRAINT employeeposition_employeekey_fkey FOREIGN KEY (employeekey) REFERENCES public.employee(employeekey);


--
-- Name: employeeposition employeeposition_positionkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employeeposition
    ADD CONSTRAINT employeeposition_positionkey_fkey FOREIGN KEY (positionkey) REFERENCES public.jobposition(positionkey);


--
-- Name: grantapplication grantapplication_granttypekey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grantapplication
    ADD CONSTRAINT grantapplication_granttypekey_fkey FOREIGN KEY (granttypekey) REFERENCES public.granttype(granttypekey);


--
-- Name: grantapplication grantapplication_personkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grantapplication
    ADD CONSTRAINT grantapplication_personkey_fkey FOREIGN KEY (personkey) REFERENCES public.person(personkey);


--
-- Name: grantreview grantreview_employeekey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grantreview
    ADD CONSTRAINT grantreview_employeekey_fkey FOREIGN KEY (employeekey) REFERENCES public.employee(employeekey);


--
-- Name: grantreview grantreview_grantapplicationkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grantreview
    ADD CONSTRAINT grantreview_grantapplicationkey_fkey FOREIGN KEY (grantapplicationkey) REFERENCES public.grantapplication(grantapplicationkey);


--
-- Name: grantstatus grantstatus_grantapplicationkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grantstatus
    ADD CONSTRAINT grantstatus_grantapplicationkey_fkey FOREIGN KEY (grantapplicationkey) REFERENCES public.grantapplication(grantapplicationkey);


--
-- Name: grantstatus grantstatus_statuskey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grantstatus
    ADD CONSTRAINT grantstatus_statuskey_fkey FOREIGN KEY (statuskey) REFERENCES public.status(statuskey);


--
-- Name: loginhistory loginhistory_loginkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loginhistory
    ADD CONSTRAINT loginhistory_loginkey_fkey FOREIGN KEY (loginkey) REFERENCES public.logintable(loginkey);


--
-- Name: logintable logintable_personkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logintable
    ADD CONSTRAINT logintable_personkey_fkey FOREIGN KEY (personkey) REFERENCES public.person(personkey);


--
-- Name: logintable logintable_personkey_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logintable
    ADD CONSTRAINT logintable_personkey_fkey1 FOREIGN KEY (personkey) REFERENCES public.person(personkey);


--
-- Name: personaddress personaddress_personkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personaddress
    ADD CONSTRAINT personaddress_personkey_fkey FOREIGN KEY (personkey) REFERENCES public.person(personkey);


--
-- Name: topdonors; Type: MATERIALIZED VIEW DATA; Schema: donorschema; Owner: postgres
--

REFRESH MATERIALIZED VIEW donorschema.topdonors;


--
-- Name: grantreview; Type: MATERIALIZED VIEW DATA; Schema: employeeschema; Owner: postgres
--

REFRESH MATERIALIZED VIEW employeeschema.grantreview;


--
-- PostgreSQL database dump complete
--

