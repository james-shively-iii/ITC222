--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6
-- Dumped by pg_dump version 10.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.substitution DROP CONSTRAINT substitution_substitutekey_fkey;
ALTER TABLE ONLY public.substitution DROP CONSTRAINT substitution_studentkey_fkey;
ALTER TABLE ONLY public.substitution DROP CONSTRAINT substitution_coursekey_fkey;
ALTER TABLE ONLY public.substitution DROP CONSTRAINT substitution_certificatekey_fkey;
ALTER TABLE ONLY public.substitution DROP CONSTRAINT substitution_certadminkey_fkey;
ALTER TABLE ONLY public.student DROP CONSTRAINT student_statuskey_fkey;
ALTER TABLE ONLY public.student DROP CONSTRAINT student_personkey_fkey;
ALTER TABLE ONLY public.seminardetails DROP CONSTRAINT seminarkey_fk;
ALTER TABLE ONLY public.attendance DROP CONSTRAINT seminardetails_seminardk_fk;
ALTER TABLE ONLY public.roster DROP CONSTRAINT roster_studentkey_fkey;
ALTER TABLE ONLY public.roster DROP CONSTRAINT roster_sectionkey_fkey;
ALTER TABLE ONLY public.attendance DROP CONSTRAINT person_personkey_fk;
ALTER TABLE ONLY public.logintable DROP CONSTRAINT logintable_personkey_fkey;
ALTER TABLE ONLY public.loginhistory DROP CONSTRAINT loginhistory_logintablekey_fkey;
ALTER TABLE ONLY public.seminar DROP CONSTRAINT location_locationkey_fk;
ALTER TABLE ONLY public.seminardetails DROP CONSTRAINT instructorkey_fk;
ALTER TABLE ONLY public.instructorarea DROP CONSTRAINT instructorarea_instructorkey_fkey;
ALTER TABLE ONLY public.instructorarea DROP CONSTRAINT instructorarea_instructionalareakey_fkey;
ALTER TABLE ONLY public.instructor DROP CONSTRAINT instructor_statuskey_fkey;
ALTER TABLE ONLY public.instructor DROP CONSTRAINT instructor_personkey_fkey;
ALTER TABLE ONLY public.coursesection DROP CONSTRAINT fk_quarter;
ALTER TABLE ONLY public.coursesection DROP CONSTRAINT fk_price;
ALTER TABLE ONLY public.coursesection DROP CONSTRAINT coursesection_instructorkey_fkey;
ALTER TABLE ONLY public.coursesection DROP CONSTRAINT coursesection_coursekey_fkey;
ALTER TABLE ONLY public.certificatecourse DROP CONSTRAINT certificatecourse_coursekey_fkey;
ALTER TABLE ONLY public.certificatecourse DROP CONSTRAINT certificatecourse_certificatekey_fkey;
ALTER TABLE ONLY public.certadmin DROP CONSTRAINT certadmin_statuskey_fkey;
ALTER TABLE ONLY public.certadmin DROP CONSTRAINT certadmin_personkey_fkey;
DROP TRIGGER flag_finalgrade ON public.roster;
DROP TRIGGER fires_flag_finalgrade ON public.roster;
DROP TRIGGER fires_finalgradeflag ON public.roster;
DROP TRIGGER fire_fgf ON public.roster;
DROP INDEX public.roster_studentkey_idx;
DROP INDEX public.person_lastname_idx;
DROP INDEX public.coursesection_coursekey_quarterkey_sectionyear_idx;
ALTER TABLE ONLY public.person DROP CONSTRAINT unique_email;
ALTER TABLE ONLY public.substitution DROP CONSTRAINT substitution_pkey;
ALTER TABLE ONLY public.student DROP CONSTRAINT student_pkey;
ALTER TABLE ONLY public.status DROP CONSTRAINT status_pkey;
ALTER TABLE ONLY public.seminardetails DROP CONSTRAINT seminardetails_pkey;
ALTER TABLE ONLY public.seminar DROP CONSTRAINT seminar_pk;
ALTER TABLE ONLY public.roster DROP CONSTRAINT roster_pkey;
ALTER TABLE ONLY public.quarter DROP CONSTRAINT quarter_pkey;
ALTER TABLE ONLY public.pricehistory DROP CONSTRAINT pricehistory_pkey;
ALTER TABLE ONLY public.instructorarea DROP CONSTRAINT pk_instructorarea;
ALTER TABLE ONLY public.certificatecourse DROP CONSTRAINT pk_certificatecourse;
ALTER TABLE ONLY public.person DROP CONSTRAINT person_pkey;
ALTER TABLE ONLY public.logintable DROP CONSTRAINT logintable_pkey;
ALTER TABLE ONLY public.loginhistory DROP CONSTRAINT loginhistory_pkey;
ALTER TABLE ONLY public.location DROP CONSTRAINT location_pk;
ALTER TABLE ONLY public.location DROP CONSTRAINT location_email_key;
ALTER TABLE ONLY public.instructor DROP CONSTRAINT instructor_pkey;
ALTER TABLE ONLY public.instructionalarea DROP CONSTRAINT instructionalarea_pkey;
ALTER TABLE ONLY public.coursesection DROP CONSTRAINT coursesection_pkey;
ALTER TABLE ONLY public.course DROP CONSTRAINT course_pkey;
ALTER TABLE ONLY public.certificate DROP CONSTRAINT certificate_pkey;
ALTER TABLE ONLY public.certadmin DROP CONSTRAINT certadmin_pkey;
ALTER TABLE ONLY public.businessrule DROP CONSTRAINT businessrule_pkey;
ALTER TABLE ONLY public.attendance DROP CONSTRAINT attendancekey_pk;
ALTER TABLE public.substitution ALTER COLUMN substitutionkey DROP DEFAULT;
ALTER TABLE public.student ALTER COLUMN studentkey DROP DEFAULT;
ALTER TABLE public.status ALTER COLUMN statuskey DROP DEFAULT;
ALTER TABLE public.seminardetails ALTER COLUMN seminardetailkey DROP DEFAULT;
ALTER TABLE public.seminar ALTER COLUMN seminarkey DROP DEFAULT;
ALTER TABLE public.roster ALTER COLUMN rosterkey DROP DEFAULT;
ALTER TABLE public.quarter ALTER COLUMN quarterkey DROP DEFAULT;
ALTER TABLE public.pricehistory ALTER COLUMN pricehistorykey DROP DEFAULT;
ALTER TABLE public.person ALTER COLUMN personkey DROP DEFAULT;
ALTER TABLE public.logintable ALTER COLUMN logintablekey DROP DEFAULT;
ALTER TABLE public.loginhistory ALTER COLUMN loginhistorykey DROP DEFAULT;
ALTER TABLE public.location ALTER COLUMN locationkey DROP DEFAULT;
ALTER TABLE public.instructor ALTER COLUMN instructorkey DROP DEFAULT;
ALTER TABLE public.instructionalarea ALTER COLUMN instructionalareakey DROP DEFAULT;
ALTER TABLE public.coursesection ALTER COLUMN sectionkey DROP DEFAULT;
ALTER TABLE public.course ALTER COLUMN coursekey DROP DEFAULT;
ALTER TABLE public.certificate ALTER COLUMN certificatekey DROP DEFAULT;
ALTER TABLE public.certadmin ALTER COLUMN certadminkey DROP DEFAULT;
ALTER TABLE public.businessrule ALTER COLUMN businessrulekey DROP DEFAULT;
ALTER TABLE public.attendance ALTER COLUMN attendancekey DROP DEFAULT;
DROP SEQUENCE public.substitution_substitutionkey_seq;
DROP TABLE public.substitution;
DROP SEQUENCE public.student_studentkey_seq;
DROP SEQUENCE public.status_statuskey_seq;
DROP SEQUENCE public.seminardetails_seminardetailkey_seq;
DROP TABLE public.seminardetails;
DROP SEQUENCE public.seminar_seminarkey_seq;
DROP TABLE public.seminar;
DROP SEQUENCE public.roster_rosterkey_seq;
DROP SEQUENCE public.quarter_quarterkey_seq;
DROP TABLE public.quarter;
DROP SEQUENCE public.pricehistory_pricehistorykey_seq;
DROP TABLE public.pricehistory;
DROP SEQUENCE public.person_personkey_seq;
DROP SEQUENCE public.logintable_logintablekey_seq;
DROP TABLE public.logintable;
DROP SEQUENCE public.loginhistory_loginhistorykey_seq;
DROP TABLE public.loginhistory;
DROP SEQUENCE public.location_locationkey_seq;
DROP TABLE public.location;
DROP TABLE public.instructorarea;
DROP SEQUENCE public.instructor_instructorkey_seq;
DROP TABLE public.instructor;
DROP SEQUENCE public.instructionalarea_instructionalareakey_seq;
DROP TABLE public.instructionalarea;
DROP SEQUENCE public.coursesection_sectionkey_seq;
DROP TABLE public.coursesection;
DROP SEQUENCE public.course_coursekey_seq;
DROP TABLE public.course;
DROP TABLE public.certificatecourse;
DROP SEQUENCE public.certificate_certificatekey_seq;
DROP TABLE public.certificate;
DROP SEQUENCE public.certadmin_certadminkey_seq;
DROP TABLE public.certadmin;
DROP SEQUENCE public.businessrule_businessrulekey_seq;
DROP TABLE public.businessrule;
DROP SEQUENCE public.attendance_attendancekey_seq;
DROP TABLE public.attendance;
DROP MATERIALIZED VIEW instructorschema.studentstatus;
DROP TABLE public.status;
DROP VIEW instructorschema.roster71;
DROP TABLE public.student;
DROP TABLE public.roster;
DROP VIEW instructorschema.people;
DROP TABLE public.person;
DROP FUNCTION public.updatestudent(sk integer, "First Name" text, "Last Name" text, email text, phone character, address text, city text, "State" character, zip text);
DROP FUNCTION public.totalofcredits4(studentkey1 integer);
DROP FUNCTION public.setflag2();
DROP FUNCTION public.setflag();
DROP FUNCTION public.makeusername(firstname text, lastname text);
DROP FUNCTION public.createpassword(pass character varying);
DROP FUNCTION public.coursestaken(sk integer);
DROP FUNCTION public.courseprice(sk integer);
DROP FUNCTION public.coursecreds(sk integer);
DROP FUNCTION public.costofsection3(sectionkey1 integer);
DROP FUNCTION public.certcredits(certkey integer);
DROP FUNCTION public.assign_grade(skey integer);
DROP FUNCTION public.addstudent("First Name" text, "Last Name" text, email text, address text, city text, "State" character, zip text, phone character, newsletter boolean, status integer, pass text);
DROP EXTENSION pgcrypto;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
DROP SCHEMA instructorschema;
--
-- Name: instructorschema; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA instructorschema;


ALTER SCHEMA instructorschema OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: addstudent(text, text, text, text, text, character, text, character, boolean, integer, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.addstudent("First Name" text, "Last Name" text, email text, address text, city text, "State" character, zip text, phone character, newsletter boolean, status integer, pass text) RETURNS void
    LANGUAGE sql
    AS $$
INSERT INTO person (firstname, lastname, email, address, city, state, postalcode, phone, dateadded, newsletter)
VALUES ("First Name", "Last Name", Email, Address, City, "State", Zip, Phone, current_timestamp, Newsletter);
INSERT INTO student (personkey, studentstartdate, statuskey)
VALUES (currval('person_personkey_seq'), current_timestamp, Status);
INSERT INTO logintable(username, personkey, userpassword, datelastchanged)
VALUES (makeusername("First Name", "Last Name"), currval('person_personkey_seq'), crypt(Pass, gen_salt('bf', 8)), current_timestamp);
$$;


ALTER FUNCTION public.addstudent("First Name" text, "Last Name" text, email text, address text, city text, "State" character, zip text, phone character, newsletter boolean, status integer, pass text) OWNER TO postgres;

--
-- Name: assign_grade(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.assign_grade(skey integer) RETURNS numeric
    LANGUAGE sql
    AS $$

Update Roster
set finalgrade=Random()*(5-1)+1
where studentkey=skey
returning finalgrade

$$;


ALTER FUNCTION public.assign_grade(skey integer) OWNER TO postgres;

--
-- Name: certcredits(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.certcredits(certkey integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN (
	SELECT SUM(credits) 
	FROM course c
	INNER JOIN certificatecourse cc
	ON c.coursekey=cc.coursekey
	INNER JOIN certificate cert 
	ON cc.certificatekey=cert.certificatekey
	WHERE cert.certificatekey=certkey
);
END;
$$;


ALTER FUNCTION public.certcredits(certkey integer) OWNER TO postgres;

--
-- Name: costofsection3(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.costofsection3(sectionkey1 integer) RETURNS TABLE(sektionkey11 integer, costofsection numeric, costofsectiondiscounted numeric)
    LANGUAGE plpgsql
    AS $$
begin
return query
select coursesection.sectionkey,
(sum(course.credits)*pricehistory.pricepercredit) as "Total Cost without discount",
(sum(course.credits)*pricehistory.pricepercredit*(1-pricehistory.pricediscount)) as "Total Cost with discount"
from course
inner join coursesection on course.coursekey = coursesection.coursekey
inner join pricehistory on pricehistory.pricehistorykey = coursesection.pricehistorykey
where coursesection.sectionkey = sectionkey1
group by coursesection.sectionkey, pricehistory.pricepercredit, (1-pricehistory.pricediscount);
end;
$$;


ALTER FUNCTION public.costofsection3(sectionkey1 integer) OWNER TO postgres;

--
-- Name: coursecreds(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.coursecreds(sk integer) RETURNS TABLE("Credits Taken" bigint)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
SELECT SUM(c.credits) AS "Credits Taken"
FROM student s
INNER JOIN roster r 
ON s.studentkey = r.studentkey
INNER JOIN coursesection cs
ON r.sectionkey = cs.sectionkey
INNER JOIN course c 
ON cs.coursekey = c.coursekey
WHERE s.studentkey = sk;
END;
$$;


ALTER FUNCTION public.coursecreds(sk integer) OWNER TO postgres;

--
-- Name: courseprice(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.courseprice(sk integer) RETURNS TABLE("Base Cost" numeric, "Discounted" numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
SELECT
(SUM(c.credits) * ph.pricepercredit) AS "Base Cost", 
(SUM(c.credits) * ph.pricepercredit * (1 - ph.pricediscount)) AS "Discounted"
FROM course c
INNER JOIN coursesection cs
ON c.coursekey=cs.coursekey
INNER JOIN pricehistory ph
ON ph.pricehistorykey=cs.pricehistorykey
WHERE cs.sectionkey=sk
GROUP BY cs.sectionkey, ph.pricepercredit, ph.pricediscount;
END;
$$;


ALTER FUNCTION public.courseprice(sk integer) OWNER TO postgres;

--
-- Name: coursestaken(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.coursestaken(sk integer) RETURNS TABLE("Courses Taken" text, "Course Credits" integer, "Final Grade" numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
SELECT coursename, credits, finalgrade
FROM student s
INNER JOIN roster r 
ON s.studentkey=r.studentkey
INNER JOIN coursesection cs 
ON cs.sectionkey=r.sectionkey
INNER JOIN course c
ON c.coursekey=cs.coursekey
WHERE s.studentkey=sk
AND finalgrade IS NOT NULL;
END;
$$;


ALTER FUNCTION public.coursestaken(sk integer) OWNER TO postgres;

--
-- Name: createpassword(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.createpassword(pass character varying) RETURNS text
    LANGUAGE sql
    AS $$
Select crypt(pass, gen_salt('bf', 8))
$$;


ALTER FUNCTION public.createpassword(pass character varying) OWNER TO postgres;

--
-- Name: makeusername(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.makeusername(firstname text, lastname text) RETURNS text
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN SUBSTRING(firstname, 1,1) || lastname;
END;
$$;


ALTER FUNCTION public.makeusername(firstname text, lastname text) OWNER TO postgres;

--
-- Name: setflag(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.setflag() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
IF NEW.finalgrade < 2.0
THEN
UPDATE roster r
SET lowgradeflag = TRUE
WHERE r.rosterkey = NEW.rosterkey;
END IF;
RETURN NEW;
END;
$$;


ALTER FUNCTION public.setflag() OWNER TO postgres;

--
-- Name: setflag2(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.setflag2() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
if NEW.finalgrade < 2.0
then
update roster
set lowgradeflag = TRUE
where roster.rosterkey = NEW.rosterkey;
else
set lowgradeflag = false;
END IF;
return NEW;
end;
$$;


ALTER FUNCTION public.setflag2() OWNER TO postgres;

--
-- Name: totalofcredits4(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.totalofcredits4(studentkey1 integer) RETURNS TABLE(tbstudentkey integer, tbstcredits bigint)
    LANGUAGE plpgsql
    AS $$
begin
return query
select student.studentkey, sum(course.credits) as "Total credit"
from student
inner join roster on student.studentkey = roster.studentkey
inner join coursesection on roster.sectionkey = coursesection.sectionkey
inner join course on coursesection.coursekey = course.coursekey
where student.studentkey = studentkey1
group by student.studentkey;
end;
$$;


ALTER FUNCTION public.totalofcredits4(studentkey1 integer) OWNER TO postgres;

--
-- Name: updatestudent(integer, text, text, text, character, text, text, character, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.updatestudent(sk integer, "First Name" text, "Last Name" text, email text, phone character, address text, city text, "State" character, zip text) RETURNS void
    LANGUAGE sql
    AS $$
UPDATE person p
SET firstname="First Name", lastname="Last Name", email=Email, phone=Phone, address=Address, city=City, 
state="State", postalcode=Zip
WHERE p.personkey=(SELECT s.personkey FROM student s WHERE s.studentkey=SK);
$$;


ALTER FUNCTION public.updatestudent(sk integer, "First Name" text, "Last Name" text, email text, phone character, address text, city text, "State" character, zip text) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: person; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.person (
    personkey integer NOT NULL,
    lastname text NOT NULL,
    firstname text,
    email text NOT NULL,
    address text,
    city text,
    state character(2),
    postalcode text,
    phone character(14),
    dateadded date,
    newsletter boolean DEFAULT true
);


ALTER TABLE public.person OWNER TO postgres;

--
-- Name: people; Type: VIEW; Schema: instructorschema; Owner: postgres
--

CREATE VIEW instructorschema.people AS
 SELECT person.personkey AS "PK",
    person.lastname AS "Last",
    person.firstname AS "First",
    person.email AS "Email",
    person.address AS "Address",
    person.city AS "City",
    person.state AS "State",
    person.postalcode AS "Zip",
    person.phone AS "Phone",
    person.dateadded AS "Date Added"
   FROM public.person
  WHERE (person.state = 'WA'::bpchar)
  ORDER BY person.dateadded
  WITH CASCADED CHECK OPTION;


ALTER TABLE instructorschema.people OWNER TO postgres;

--
-- Name: roster; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roster (
    rosterkey integer NOT NULL,
    sectionkey integer,
    studentkey integer,
    finalgrade numeric,
    lowgradeflag boolean DEFAULT false,
    CONSTRAINT chk_grade CHECK (((finalgrade >= (0)::numeric) AND (finalgrade <= (4)::numeric)))
);


ALTER TABLE public.roster OWNER TO postgres;

--
-- Name: student; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student (
    studentkey integer NOT NULL,
    personkey integer,
    studentstartdate date NOT NULL,
    statuskey integer
);


ALTER TABLE public.student OWNER TO postgres;

--
-- Name: roster71; Type: VIEW; Schema: instructorschema; Owner: postgres
--

CREATE VIEW instructorschema.roster71 AS
 SELECT r.studentkey AS "ID",
    ((p.lastname || ', '::text) || p.firstname) AS "Name",
    p.email AS "Email"
   FROM ((public.person p
     JOIN public.student s ON ((p.personkey = s.personkey)))
     JOIN public.roster r ON ((s.studentkey = r.studentkey)))
  WHERE (r.sectionkey = 71)
  ORDER BY r.studentkey;


ALTER TABLE instructorschema.roster71 OWNER TO postgres;

--
-- Name: status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status (
    statuskey integer NOT NULL,
    statusname text NOT NULL
);


ALTER TABLE public.status OWNER TO postgres;

--
-- Name: studentstatus; Type: MATERIALIZED VIEW; Schema: instructorschema; Owner: postgres
--

CREATE MATERIALIZED VIEW instructorschema.studentstatus AS
 SELECT DISTINCT ON (s.studentkey) s.studentkey AS "ID Key",
    ((p.lastname || ', '::text) || p.firstname) AS "Name",
    s.studentstartdate AS "Start Date",
    st.statusname AS "Status"
   FROM (((public.student s
     JOIN public.person p ON ((p.personkey = s.personkey)))
     JOIN public.roster r ON ((r.studentkey = s.studentkey)))
     JOIN public.status st ON ((st.statuskey = s.statuskey)))
  ORDER BY s.studentkey
  WITH NO DATA;


ALTER TABLE instructorschema.studentstatus OWNER TO postgres;

--
-- Name: attendance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendance (
    attendancekey integer NOT NULL,
    seminardetailkey integer NOT NULL,
    personkey integer NOT NULL
);


ALTER TABLE public.attendance OWNER TO postgres;

--
-- Name: attendance_attendancekey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attendance_attendancekey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.attendance_attendancekey_seq OWNER TO postgres;

--
-- Name: attendance_attendancekey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attendance_attendancekey_seq OWNED BY public.attendance.attendancekey;


--
-- Name: businessrule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.businessrule (
    businessrulekey integer NOT NULL,
    businessruletext text
);


ALTER TABLE public.businessrule OWNER TO postgres;

--
-- Name: businessrule_businessrulekey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.businessrule_businessrulekey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.businessrule_businessrulekey_seq OWNER TO postgres;

--
-- Name: businessrule_businessrulekey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.businessrule_businessrulekey_seq OWNED BY public.businessrule.businessrulekey;


--
-- Name: certadmin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.certadmin (
    certadminkey integer NOT NULL,
    personkey integer,
    statuskey integer
);


ALTER TABLE public.certadmin OWNER TO postgres;

--
-- Name: certadmin_certadminkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.certadmin_certadminkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.certadmin_certadminkey_seq OWNER TO postgres;

--
-- Name: certadmin_certadminkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.certadmin_certadminkey_seq OWNED BY public.certadmin.certadminkey;


--
-- Name: certificate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.certificate (
    certificatekey integer NOT NULL,
    certificatename text NOT NULL,
    certificatedescription text
);


ALTER TABLE public.certificate OWNER TO postgres;

--
-- Name: certificate_certificatekey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.certificate_certificatekey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.certificate_certificatekey_seq OWNER TO postgres;

--
-- Name: certificate_certificatekey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.certificate_certificatekey_seq OWNED BY public.certificate.certificatekey;


--
-- Name: certificatecourse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.certificatecourse (
    certificatekey integer NOT NULL,
    coursekey integer NOT NULL,
    minimumgrade numeric NOT NULL
);


ALTER TABLE public.certificatecourse OWNER TO postgres;

--
-- Name: course; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.course (
    coursekey integer NOT NULL,
    coursename text NOT NULL,
    credits integer NOT NULL,
    coursedescription text
);


ALTER TABLE public.course OWNER TO postgres;

--
-- Name: course_coursekey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.course_coursekey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_coursekey_seq OWNER TO postgres;

--
-- Name: course_coursekey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.course_coursekey_seq OWNED BY public.course.coursekey;


--
-- Name: coursesection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coursesection (
    sectionkey integer NOT NULL,
    coursekey integer,
    instructorkey integer,
    sectionyear integer NOT NULL,
    pricehistorykey integer,
    quarterkey integer
);


ALTER TABLE public.coursesection OWNER TO postgres;

--
-- Name: coursesection_sectionkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.coursesection_sectionkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.coursesection_sectionkey_seq OWNER TO postgres;

--
-- Name: coursesection_sectionkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.coursesection_sectionkey_seq OWNED BY public.coursesection.sectionkey;


--
-- Name: instructionalarea; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.instructionalarea (
    instructionalareakey integer NOT NULL,
    areaname text NOT NULL,
    description text
);


ALTER TABLE public.instructionalarea OWNER TO postgres;

--
-- Name: instructionalarea_instructionalareakey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.instructionalarea_instructionalareakey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.instructionalarea_instructionalareakey_seq OWNER TO postgres;

--
-- Name: instructionalarea_instructionalareakey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.instructionalarea_instructionalareakey_seq OWNED BY public.instructionalarea.instructionalareakey;


--
-- Name: instructor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.instructor (
    instructorkey integer NOT NULL,
    personkey integer,
    hiredate date NOT NULL,
    statuskey integer
);


ALTER TABLE public.instructor OWNER TO postgres;

--
-- Name: instructor_instructorkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.instructor_instructorkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.instructor_instructorkey_seq OWNER TO postgres;

--
-- Name: instructor_instructorkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.instructor_instructorkey_seq OWNED BY public.instructor.instructorkey;


--
-- Name: instructorarea; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.instructorarea (
    instructionalareakey integer NOT NULL,
    instructorkey integer NOT NULL
);


ALTER TABLE public.instructorarea OWNER TO postgres;

--
-- Name: location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.location (
    locationkey integer NOT NULL,
    locationname text NOT NULL,
    locationaddress text NOT NULL,
    locationcity text NOT NULL,
    locationstate character(2) NOT NULL,
    postalcode character varying(12) NOT NULL,
    phone character varying(13) NOT NULL,
    email text NOT NULL
);


ALTER TABLE public.location OWNER TO postgres;

--
-- Name: location_locationkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.location_locationkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.location_locationkey_seq OWNER TO postgres;

--
-- Name: location_locationkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.location_locationkey_seq OWNED BY public.location.locationkey;


--
-- Name: loginhistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loginhistory (
    loginhistorykey integer NOT NULL,
    logintablekey integer,
    logindate date DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.loginhistory OWNER TO postgres;

--
-- Name: loginhistory_loginhistorykey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.loginhistory_loginhistorykey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.loginhistory_loginhistorykey_seq OWNER TO postgres;

--
-- Name: loginhistory_loginhistorykey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.loginhistory_loginhistorykey_seq OWNED BY public.loginhistory.loginhistorykey;


--
-- Name: logintable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logintable (
    logintablekey integer NOT NULL,
    username text,
    personkey integer,
    userpassword text,
    datelastchanged date
);


ALTER TABLE public.logintable OWNER TO postgres;

--
-- Name: logintable_logintablekey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.logintable_logintablekey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logintable_logintablekey_seq OWNER TO postgres;

--
-- Name: logintable_logintablekey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.logintable_logintablekey_seq OWNED BY public.logintable.logintablekey;


--
-- Name: person_personkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.person_personkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.person_personkey_seq OWNER TO postgres;

--
-- Name: person_personkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.person_personkey_seq OWNED BY public.person.personkey;


--
-- Name: pricehistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pricehistory (
    pricehistorykey integer NOT NULL,
    pricebegindate date NOT NULL,
    pricepercredit numeric(10,2) NOT NULL,
    pricediscount numeric(3,2)
);


ALTER TABLE public.pricehistory OWNER TO postgres;

--
-- Name: pricehistory_pricehistorykey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pricehistory_pricehistorykey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pricehistory_pricehistorykey_seq OWNER TO postgres;

--
-- Name: pricehistory_pricehistorykey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pricehistory_pricehistorykey_seq OWNED BY public.pricehistory.pricehistorykey;


--
-- Name: quarter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quarter (
    quarterkey integer NOT NULL,
    quartername text
);


ALTER TABLE public.quarter OWNER TO postgres;

--
-- Name: quarter_quarterkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quarter_quarterkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quarter_quarterkey_seq OWNER TO postgres;

--
-- Name: quarter_quarterkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quarter_quarterkey_seq OWNED BY public.quarter.quarterkey;


--
-- Name: roster_rosterkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roster_rosterkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roster_rosterkey_seq OWNER TO postgres;

--
-- Name: roster_rosterkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roster_rosterkey_seq OWNED BY public.roster.rosterkey;


--
-- Name: seminar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.seminar (
    seminarkey integer NOT NULL,
    locationkey integer NOT NULL,
    theme text NOT NULL,
    seminardate date NOT NULL,
    description text
);


ALTER TABLE public.seminar OWNER TO postgres;

--
-- Name: seminar_seminarkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.seminar_seminarkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seminar_seminarkey_seq OWNER TO postgres;

--
-- Name: seminar_seminarkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.seminar_seminarkey_seq OWNED BY public.seminar.seminarkey;


--
-- Name: seminardetails; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.seminardetails (
    seminardetailkey integer NOT NULL,
    seminarkey integer NOT NULL,
    topic text NOT NULL,
    presenttime time without time zone,
    room character(5),
    instructorkey integer,
    description text
);


ALTER TABLE public.seminardetails OWNER TO postgres;

--
-- Name: seminardetails_seminardetailkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.seminardetails_seminardetailkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seminardetails_seminardetailkey_seq OWNER TO postgres;

--
-- Name: seminardetails_seminardetailkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.seminardetails_seminardetailkey_seq OWNED BY public.seminardetails.seminardetailkey;


--
-- Name: status_statuskey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.status_statuskey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_statuskey_seq OWNER TO postgres;

--
-- Name: status_statuskey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.status_statuskey_seq OWNED BY public.status.statuskey;


--
-- Name: student_studentkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_studentkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.student_studentkey_seq OWNER TO postgres;

--
-- Name: student_studentkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_studentkey_seq OWNED BY public.student.studentkey;


--
-- Name: substitution; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.substitution (
    substitutionkey integer NOT NULL,
    certificatekey integer,
    coursekey integer,
    substitutekey integer,
    studentkey integer,
    certadminkey integer
);


ALTER TABLE public.substitution OWNER TO postgres;

--
-- Name: substitution_substitutionkey_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.substitution_substitutionkey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.substitution_substitutionkey_seq OWNER TO postgres;

--
-- Name: substitution_substitutionkey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.substitution_substitutionkey_seq OWNED BY public.substitution.substitutionkey;


--
-- Name: attendance attendancekey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance ALTER COLUMN attendancekey SET DEFAULT nextval('public.attendance_attendancekey_seq'::regclass);


--
-- Name: businessrule businessrulekey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.businessrule ALTER COLUMN businessrulekey SET DEFAULT nextval('public.businessrule_businessrulekey_seq'::regclass);


--
-- Name: certadmin certadminkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certadmin ALTER COLUMN certadminkey SET DEFAULT nextval('public.certadmin_certadminkey_seq'::regclass);


--
-- Name: certificate certificatekey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificate ALTER COLUMN certificatekey SET DEFAULT nextval('public.certificate_certificatekey_seq'::regclass);


--
-- Name: course coursekey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course ALTER COLUMN coursekey SET DEFAULT nextval('public.course_coursekey_seq'::regclass);


--
-- Name: coursesection sectionkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coursesection ALTER COLUMN sectionkey SET DEFAULT nextval('public.coursesection_sectionkey_seq'::regclass);


--
-- Name: instructionalarea instructionalareakey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructionalarea ALTER COLUMN instructionalareakey SET DEFAULT nextval('public.instructionalarea_instructionalareakey_seq'::regclass);


--
-- Name: instructor instructorkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructor ALTER COLUMN instructorkey SET DEFAULT nextval('public.instructor_instructorkey_seq'::regclass);


--
-- Name: location locationkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location ALTER COLUMN locationkey SET DEFAULT nextval('public.location_locationkey_seq'::regclass);


--
-- Name: loginhistory loginhistorykey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loginhistory ALTER COLUMN loginhistorykey SET DEFAULT nextval('public.loginhistory_loginhistorykey_seq'::regclass);


--
-- Name: logintable logintablekey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logintable ALTER COLUMN logintablekey SET DEFAULT nextval('public.logintable_logintablekey_seq'::regclass);


--
-- Name: person personkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person ALTER COLUMN personkey SET DEFAULT nextval('public.person_personkey_seq'::regclass);


--
-- Name: pricehistory pricehistorykey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pricehistory ALTER COLUMN pricehistorykey SET DEFAULT nextval('public.pricehistory_pricehistorykey_seq'::regclass);


--
-- Name: quarter quarterkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quarter ALTER COLUMN quarterkey SET DEFAULT nextval('public.quarter_quarterkey_seq'::regclass);


--
-- Name: roster rosterkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roster ALTER COLUMN rosterkey SET DEFAULT nextval('public.roster_rosterkey_seq'::regclass);


--
-- Name: seminar seminarkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seminar ALTER COLUMN seminarkey SET DEFAULT nextval('public.seminar_seminarkey_seq'::regclass);


--
-- Name: seminardetails seminardetailkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seminardetails ALTER COLUMN seminardetailkey SET DEFAULT nextval('public.seminardetails_seminardetailkey_seq'::regclass);


--
-- Name: status statuskey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status ALTER COLUMN statuskey SET DEFAULT nextval('public.status_statuskey_seq'::regclass);


--
-- Name: student studentkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student ALTER COLUMN studentkey SET DEFAULT nextval('public.student_studentkey_seq'::regclass);


--
-- Name: substitution substitutionkey; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.substitution ALTER COLUMN substitutionkey SET DEFAULT nextval('public.substitution_substitutionkey_seq'::regclass);


--
-- Data for Name: attendance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendance (attendancekey, seminardetailkey, personkey) FROM stdin;
\.
COPY public.attendance (attendancekey, seminardetailkey, personkey) FROM '$$PATH$$/3143.dat';

--
-- Data for Name: businessrule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.businessrule (businessrulekey, businessruletext) FROM stdin;
\.
COPY public.businessrule (businessrulekey, businessruletext) FROM '$$PATH$$/3102.dat';

--
-- Data for Name: certadmin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.certadmin (certadminkey, personkey, statuskey) FROM stdin;
\.
COPY public.certadmin (certadminkey, personkey, statuskey) FROM '$$PATH$$/3104.dat';

--
-- Data for Name: certificate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.certificate (certificatekey, certificatename, certificatedescription) FROM stdin;
\.
COPY public.certificate (certificatekey, certificatename, certificatedescription) FROM '$$PATH$$/3106.dat';

--
-- Data for Name: certificatecourse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.certificatecourse (certificatekey, coursekey, minimumgrade) FROM stdin;
\.
COPY public.certificatecourse (certificatekey, coursekey, minimumgrade) FROM '$$PATH$$/3108.dat';

--
-- Data for Name: course; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.course (coursekey, coursename, credits, coursedescription) FROM stdin;
\.
COPY public.course (coursekey, coursename, credits, coursedescription) FROM '$$PATH$$/3109.dat';

--
-- Data for Name: coursesection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coursesection (sectionkey, coursekey, instructorkey, sectionyear, pricehistorykey, quarterkey) FROM stdin;
\.
COPY public.coursesection (sectionkey, coursekey, instructorkey, sectionyear, pricehistorykey, quarterkey) FROM '$$PATH$$/3111.dat';

--
-- Data for Name: instructionalarea; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.instructionalarea (instructionalareakey, areaname, description) FROM stdin;
\.
COPY public.instructionalarea (instructionalareakey, areaname, description) FROM '$$PATH$$/3113.dat';

--
-- Data for Name: instructor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.instructor (instructorkey, personkey, hiredate, statuskey) FROM stdin;
\.
COPY public.instructor (instructorkey, personkey, hiredate, statuskey) FROM '$$PATH$$/3115.dat';

--
-- Data for Name: instructorarea; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.instructorarea (instructionalareakey, instructorkey) FROM stdin;
\.
COPY public.instructorarea (instructionalareakey, instructorkey) FROM '$$PATH$$/3117.dat';

--
-- Data for Name: location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.location (locationkey, locationname, locationaddress, locationcity, locationstate, postalcode, phone, email) FROM stdin;
\.
COPY public.location (locationkey, locationname, locationaddress, locationcity, locationstate, postalcode, phone, email) FROM '$$PATH$$/3137.dat';

--
-- Data for Name: loginhistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loginhistory (loginhistorykey, logintablekey, logindate) FROM stdin;
\.
COPY public.loginhistory (loginhistorykey, logintablekey, logindate) FROM '$$PATH$$/3118.dat';

--
-- Data for Name: logintable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logintable (logintablekey, username, personkey, userpassword, datelastchanged) FROM stdin;
\.
COPY public.logintable (logintablekey, username, personkey, userpassword, datelastchanged) FROM '$$PATH$$/3120.dat';

--
-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.person (personkey, lastname, firstname, email, address, city, state, postalcode, phone, dateadded, newsletter) FROM stdin;
\.
COPY public.person (personkey, lastname, firstname, email, address, city, state, postalcode, phone, dateadded, newsletter) FROM '$$PATH$$/3122.dat';

--
-- Data for Name: pricehistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pricehistory (pricehistorykey, pricebegindate, pricepercredit, pricediscount) FROM stdin;
\.
COPY public.pricehistory (pricehistorykey, pricebegindate, pricepercredit, pricediscount) FROM '$$PATH$$/3124.dat';

--
-- Data for Name: quarter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quarter (quarterkey, quartername) FROM stdin;
\.
COPY public.quarter (quarterkey, quartername) FROM '$$PATH$$/3126.dat';

--
-- Data for Name: roster; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roster (rosterkey, sectionkey, studentkey, finalgrade, lowgradeflag) FROM stdin;
\.
COPY public.roster (rosterkey, sectionkey, studentkey, finalgrade, lowgradeflag) FROM '$$PATH$$/3128.dat';

--
-- Data for Name: seminar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.seminar (seminarkey, locationkey, theme, seminardate, description) FROM stdin;
\.
COPY public.seminar (seminarkey, locationkey, theme, seminardate, description) FROM '$$PATH$$/3139.dat';

--
-- Data for Name: seminardetails; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.seminardetails (seminardetailkey, seminarkey, topic, presenttime, room, instructorkey, description) FROM stdin;
\.
COPY public.seminardetails (seminardetailkey, seminarkey, topic, presenttime, room, instructorkey, description) FROM '$$PATH$$/3141.dat';

--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status (statuskey, statusname) FROM stdin;
\.
COPY public.status (statuskey, statusname) FROM '$$PATH$$/3130.dat';

--
-- Data for Name: student; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student (studentkey, personkey, studentstartdate, statuskey) FROM stdin;
\.
COPY public.student (studentkey, personkey, studentstartdate, statuskey) FROM '$$PATH$$/3132.dat';

--
-- Data for Name: substitution; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.substitution (substitutionkey, certificatekey, coursekey, substitutekey, studentkey, certadminkey) FROM stdin;
\.
COPY public.substitution (substitutionkey, certificatekey, coursekey, substitutekey, studentkey, certadminkey) FROM '$$PATH$$/3134.dat';

--
-- Name: attendance_attendancekey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attendance_attendancekey_seq', 1, false);


--
-- Name: businessrule_businessrulekey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.businessrule_businessrulekey_seq', 16, true);


--
-- Name: certadmin_certadminkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.certadmin_certadminkey_seq', 4, true);


--
-- Name: certificate_certificatekey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.certificate_certificatekey_seq', 19, true);


--
-- Name: course_coursekey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.course_coursekey_seq', 28, true);


--
-- Name: coursesection_sectionkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.coursesection_sectionkey_seq', 115, true);


--
-- Name: instructionalarea_instructionalareakey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.instructionalarea_instructionalareakey_seq', 6, true);


--
-- Name: instructor_instructorkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.instructor_instructorkey_seq', 11, true);


--
-- Name: location_locationkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.location_locationkey_seq', 1, false);


--
-- Name: loginhistory_loginhistorykey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.loginhistory_loginhistorykey_seq', 1, false);


--
-- Name: logintable_logintablekey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.logintable_logintablekey_seq', 219, true);


--
-- Name: person_personkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.person_personkey_seq', 414, true);


--
-- Name: pricehistory_pricehistorykey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pricehistory_pricehistorykey_seq', 3, true);


--
-- Name: quarter_quarterkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quarter_quarterkey_seq', 4, true);


--
-- Name: roster_rosterkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roster_rosterkey_seq', 2005, true);


--
-- Name: seminar_seminarkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.seminar_seminarkey_seq', 1, false);


--
-- Name: seminardetails_seminardetailkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.seminardetails_seminardetailkey_seq', 1, false);


--
-- Name: status_statuskey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.status_statuskey_seq', 4, true);


--
-- Name: student_studentkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_studentkey_seq', 208, true);


--
-- Name: substitution_substitutionkey_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.substitution_substitutionkey_seq', 1, false);


--
-- Name: attendance attendancekey_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendancekey_pk PRIMARY KEY (attendancekey);


--
-- Name: businessrule businessrule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.businessrule
    ADD CONSTRAINT businessrule_pkey PRIMARY KEY (businessrulekey);


--
-- Name: certadmin certadmin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certadmin
    ADD CONSTRAINT certadmin_pkey PRIMARY KEY (certadminkey);


--
-- Name: certificate certificate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificate
    ADD CONSTRAINT certificate_pkey PRIMARY KEY (certificatekey);


--
-- Name: course course_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_pkey PRIMARY KEY (coursekey);


--
-- Name: coursesection coursesection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coursesection
    ADD CONSTRAINT coursesection_pkey PRIMARY KEY (sectionkey);


--
-- Name: instructionalarea instructionalarea_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructionalarea
    ADD CONSTRAINT instructionalarea_pkey PRIMARY KEY (instructionalareakey);


--
-- Name: instructor instructor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructor
    ADD CONSTRAINT instructor_pkey PRIMARY KEY (instructorkey);


--
-- Name: location location_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location
    ADD CONSTRAINT location_email_key UNIQUE (email);


--
-- Name: location location_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location
    ADD CONSTRAINT location_pk PRIMARY KEY (locationkey);


--
-- Name: loginhistory loginhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loginhistory
    ADD CONSTRAINT loginhistory_pkey PRIMARY KEY (loginhistorykey);


--
-- Name: logintable logintable_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logintable
    ADD CONSTRAINT logintable_pkey PRIMARY KEY (logintablekey);


--
-- Name: person person_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_pkey PRIMARY KEY (personkey);


--
-- Name: certificatecourse pk_certificatecourse; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificatecourse
    ADD CONSTRAINT pk_certificatecourse PRIMARY KEY (certificatekey, coursekey);


--
-- Name: instructorarea pk_instructorarea; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructorarea
    ADD CONSTRAINT pk_instructorarea PRIMARY KEY (instructionalareakey, instructorkey);


--
-- Name: pricehistory pricehistory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pricehistory
    ADD CONSTRAINT pricehistory_pkey PRIMARY KEY (pricehistorykey);


--
-- Name: quarter quarter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quarter
    ADD CONSTRAINT quarter_pkey PRIMARY KEY (quarterkey);


--
-- Name: roster roster_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roster
    ADD CONSTRAINT roster_pkey PRIMARY KEY (rosterkey);


--
-- Name: seminar seminar_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seminar
    ADD CONSTRAINT seminar_pk PRIMARY KEY (seminarkey);


--
-- Name: seminardetails seminardetails_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seminardetails
    ADD CONSTRAINT seminardetails_pkey PRIMARY KEY (seminardetailkey);


--
-- Name: status status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_pkey PRIMARY KEY (statuskey);


--
-- Name: student student_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_pkey PRIMARY KEY (studentkey);


--
-- Name: substitution substitution_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.substitution
    ADD CONSTRAINT substitution_pkey PRIMARY KEY (substitutionkey);


--
-- Name: person unique_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT unique_email UNIQUE (email);


--
-- Name: coursesection_coursekey_quarterkey_sectionyear_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX coursesection_coursekey_quarterkey_sectionyear_idx ON public.coursesection USING btree (coursekey, quarterkey, sectionyear);


--
-- Name: person_lastname_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX person_lastname_idx ON public.person USING btree (lastname);


--
-- Name: roster_studentkey_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX roster_studentkey_idx ON public.roster USING btree (studentkey);


--
-- Name: roster fire_fgf; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER fire_fgf AFTER UPDATE ON public.roster FOR EACH ROW EXECUTE PROCEDURE public.setflag();


--
-- Name: roster fires_finalgradeflag; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER fires_finalgradeflag AFTER UPDATE ON public.roster FOR EACH ROW EXECUTE PROCEDURE public.setflag();


--
-- Name: roster fires_flag_finalgrade; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER fires_flag_finalgrade AFTER UPDATE ON public.roster FOR EACH ROW EXECUTE PROCEDURE public.setflag2();


--
-- Name: roster flag_finalgrade; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER flag_finalgrade AFTER INSERT ON public.roster FOR EACH ROW EXECUTE PROCEDURE public.setflag();


--
-- Name: certadmin certadmin_personkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certadmin
    ADD CONSTRAINT certadmin_personkey_fkey FOREIGN KEY (personkey) REFERENCES public.person(personkey);


--
-- Name: certadmin certadmin_statuskey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certadmin
    ADD CONSTRAINT certadmin_statuskey_fkey FOREIGN KEY (statuskey) REFERENCES public.status(statuskey);


--
-- Name: certificatecourse certificatecourse_certificatekey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificatecourse
    ADD CONSTRAINT certificatecourse_certificatekey_fkey FOREIGN KEY (certificatekey) REFERENCES public.certificate(certificatekey);


--
-- Name: certificatecourse certificatecourse_coursekey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificatecourse
    ADD CONSTRAINT certificatecourse_coursekey_fkey FOREIGN KEY (coursekey) REFERENCES public.course(coursekey);


--
-- Name: coursesection coursesection_coursekey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coursesection
    ADD CONSTRAINT coursesection_coursekey_fkey FOREIGN KEY (coursekey) REFERENCES public.course(coursekey);


--
-- Name: coursesection coursesection_instructorkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coursesection
    ADD CONSTRAINT coursesection_instructorkey_fkey FOREIGN KEY (instructorkey) REFERENCES public.instructor(instructorkey);


--
-- Name: coursesection fk_price; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coursesection
    ADD CONSTRAINT fk_price FOREIGN KEY (pricehistorykey) REFERENCES public.pricehistory(pricehistorykey);


--
-- Name: coursesection fk_quarter; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coursesection
    ADD CONSTRAINT fk_quarter FOREIGN KEY (quarterkey) REFERENCES public.quarter(quarterkey);


--
-- Name: instructor instructor_personkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructor
    ADD CONSTRAINT instructor_personkey_fkey FOREIGN KEY (personkey) REFERENCES public.person(personkey);


--
-- Name: instructor instructor_statuskey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructor
    ADD CONSTRAINT instructor_statuskey_fkey FOREIGN KEY (statuskey) REFERENCES public.status(statuskey);


--
-- Name: instructorarea instructorarea_instructionalareakey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructorarea
    ADD CONSTRAINT instructorarea_instructionalareakey_fkey FOREIGN KEY (instructionalareakey) REFERENCES public.instructionalarea(instructionalareakey);


--
-- Name: instructorarea instructorarea_instructorkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructorarea
    ADD CONSTRAINT instructorarea_instructorkey_fkey FOREIGN KEY (instructorkey) REFERENCES public.instructor(instructorkey);


--
-- Name: seminardetails instructorkey_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seminardetails
    ADD CONSTRAINT instructorkey_fk FOREIGN KEY (instructorkey) REFERENCES public.instructor(instructorkey);


--
-- Name: seminar location_locationkey_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seminar
    ADD CONSTRAINT location_locationkey_fk FOREIGN KEY (locationkey) REFERENCES public.location(locationkey) ON UPDATE CASCADE;


--
-- Name: loginhistory loginhistory_logintablekey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loginhistory
    ADD CONSTRAINT loginhistory_logintablekey_fkey FOREIGN KEY (logintablekey) REFERENCES public.logintable(logintablekey);


--
-- Name: logintable logintable_personkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logintable
    ADD CONSTRAINT logintable_personkey_fkey FOREIGN KEY (personkey) REFERENCES public.person(personkey);


--
-- Name: attendance person_personkey_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT person_personkey_fk FOREIGN KEY (personkey) REFERENCES public.person(personkey) ON UPDATE CASCADE;


--
-- Name: roster roster_sectionkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roster
    ADD CONSTRAINT roster_sectionkey_fkey FOREIGN KEY (sectionkey) REFERENCES public.coursesection(sectionkey);


--
-- Name: roster roster_studentkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roster
    ADD CONSTRAINT roster_studentkey_fkey FOREIGN KEY (studentkey) REFERENCES public.student(studentkey);


--
-- Name: attendance seminardetails_seminardk_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT seminardetails_seminardk_fk FOREIGN KEY (seminardetailkey) REFERENCES public.seminardetails(seminardetailkey) ON UPDATE CASCADE;


--
-- Name: seminardetails seminarkey_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seminardetails
    ADD CONSTRAINT seminarkey_fk FOREIGN KEY (seminarkey) REFERENCES public.seminar(seminarkey);


--
-- Name: student student_personkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_personkey_fkey FOREIGN KEY (personkey) REFERENCES public.person(personkey);


--
-- Name: student student_statuskey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_statuskey_fkey FOREIGN KEY (statuskey) REFERENCES public.status(statuskey);


--
-- Name: substitution substitution_certadminkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.substitution
    ADD CONSTRAINT substitution_certadminkey_fkey FOREIGN KEY (certadminkey) REFERENCES public.certadmin(certadminkey);


--
-- Name: substitution substitution_certificatekey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.substitution
    ADD CONSTRAINT substitution_certificatekey_fkey FOREIGN KEY (certificatekey) REFERENCES public.certificate(certificatekey);


--
-- Name: substitution substitution_coursekey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.substitution
    ADD CONSTRAINT substitution_coursekey_fkey FOREIGN KEY (coursekey) REFERENCES public.course(coursekey);


--
-- Name: substitution substitution_studentkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.substitution
    ADD CONSTRAINT substitution_studentkey_fkey FOREIGN KEY (studentkey) REFERENCES public.student(studentkey);


--
-- Name: substitution substitution_substitutekey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.substitution
    ADD CONSTRAINT substitution_substitutekey_fkey FOREIGN KEY (substitutekey) REFERENCES public.course(coursekey);


--
-- Name: studentstatus; Type: MATERIALIZED VIEW DATA; Schema: instructorschema; Owner: postgres
--

REFRESH MATERIALIZED VIEW instructorschema.studentstatus;


--
-- PostgreSQL database dump complete
--

